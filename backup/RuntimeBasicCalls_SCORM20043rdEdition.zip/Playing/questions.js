test.AddQuestion( new Question ("com.scorm.golfsamples.interactions.playing_1",
"Passo 1",
QUESTION_TYPE_NUMERIC,
null,
"aaa + bbb",
"obj_playing")
);

test.AddQuestion( new Question ("com.scorm.golfsamples.interactions.playing_2",
"Passo 2",
QUESTION_TYPE_NUMERIC,
null,
"bbb + ccc",
"obj_playing")
);

test.AddQuestion( new Question ("com.scorm.golfsamples.interactions.playing_3",
"Passo 3",
QUESTION_TYPE_NUMERIC,
null,
"ccc + ddd",
"obj_playing")
);

test.AddQuestion( new Question ("com.scorm.golfsamples.interactions.playing_4",
"Passo 4",
QUESTION_TYPE_NUMERIC,
null,
"zzzz",
"obj_playing")
);

test.AddQuestion( new Question ("com.scorm.golfsamples.interactions.playing_5",
"Passo 5",
QUESTION_TYPE_NUMERIC,
null,
"xxxx",
"obj_playing")
);

test.AddQuestion( new Question ("com.scorm.golfsamples.interactions.playing_6",
"Passo 6",
QUESTION_TYPE_NUMERIC,
null,
"vvvv",
"obj_playing")
);
