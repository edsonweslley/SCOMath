
test.AddQuestion(new Question ("com.scorm.golfsamples.interactions.playing_1",

                                "Passo 1",

                                QUESTION_TYPE_NUMERIC,

                                null,

                                "X = 20 - 10 - 30",

                                "obj_playing"
)
                );
    

test.AddQuestion(new Question ("com.scorm.golfsamples.interactions.playing_2",

                                "Passo 2",

                                QUESTION_TYPE_NUMERIC,

                                null,

                                "X = 20 - 40",

                                "obj_playing"
)
                );
    

test.AddQuestion(new Question ("com.scorm.golfsamples.interactions.playing_3",

                                "Passo 3",

                                QUESTION_TYPE_NUMERIC,

                                null,

                                "X = -20",

                                "obj_playing"
)
                );
    
