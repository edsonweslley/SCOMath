
test.AddQuestion(new Question ("com.scorm.golfsamples.interactions.playing_1",

                                "Passo 1",

                                QUESTION_TYPE_NUMERIC,

                                null,

                                "asdasd",

                                "obj_playing"
)
                );
    
