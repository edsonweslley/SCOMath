
test.AddQuestion(new Question ("com.scorm.golfsamples.interactions.playing_1",

                                "Passo 1",

                                QUESTION_TYPE_NUMERIC,

                                null,

                                "x = 10 - 20",

                                "obj_playing"
)
                );
    

test.AddQuestion(new Question ("com.scorm.golfsamples.interactions.playing_2",

                                "Passo 2",

                                QUESTION_TYPE_NUMERIC,

                                null,

                                "x = - 10",

                                "obj_playing"
)
                );
    
