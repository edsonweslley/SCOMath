
test.AddQuestion(new Question ("com.scorm.golfsamples.interactions.playing_1",

                                "Passo 1",

                                QUESTION_TYPE_NUMERIC,

                                null,

                                "x = 2 - 5",

                                "obj_playing"
)
                );
    

test.AddQuestion(new Question ("com.scorm.golfsamples.interactions.playing_2",

                                "Passo 2",

                                QUESTION_TYPE_NUMERIC,

                                null,

                                "x = -3",

                                "obj_playing"
)
                );
    
